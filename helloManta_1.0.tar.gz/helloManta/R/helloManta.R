helloManta <- function() {
  print("Hello Manta.")
}